// document.getElementById('botao').addEventListener('click', () => {
//     alert('Botão clicado!');
// });
  